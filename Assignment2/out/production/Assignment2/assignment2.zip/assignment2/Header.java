/* EE422C Assignment #2 submission by
 * Replace <...> with your actual data. 
 * <Farah BEy>
 * <Fkb282>
 */
