package assignment2;
import java.util.Scanner;

public class Driver {
    public static void main(String[] args) {
        Game R1 = new Game();
        R1.beginning();
    }
}
